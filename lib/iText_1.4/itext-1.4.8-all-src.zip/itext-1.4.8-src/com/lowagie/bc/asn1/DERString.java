/* see bouncycastle_license.txt */

package com.lowagie.bc.asn1;

/**
 * basic interface for DER string objects.
 */
public interface DERString
{
    public String getString();
}
